# Tomin Adonis API <!-- omit in toc -->

Aplicacion Neobanking de inclusión financiera.

## Tabla de Contenido<!-- omit in toc -->
- [Documentación de adonis](#documentaci%c3%b3n-de-adonis)

# Documentación de adonis

[Adonis](https://adonisjs.com/)
